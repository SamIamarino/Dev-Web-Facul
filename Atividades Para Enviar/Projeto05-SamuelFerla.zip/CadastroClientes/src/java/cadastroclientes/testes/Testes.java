package cadastroclientes.testes;

/**
 * Testes para o mecanismo de persistência.
 *
 * @author Prof. Dr. David Buzatto
 */
public class Testes {

    public static void main( String[] args ) throws Exception {

        // seu código aqui

    }
    
}
